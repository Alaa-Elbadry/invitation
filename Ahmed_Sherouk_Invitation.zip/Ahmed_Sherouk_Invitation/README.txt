Ahmed & Sherouk Wedding Invitation

Date: Friday, 6 November 2026
Time: 3:00 PM - 6:00 PM
Katb el Ketab: 3:30 PM
Venue: White Plaza, Ramag Hotel, El-Mushir Tantawy Axis, 5th Settlement, New Cairo
RSVP email: moalaa13469@gmail.com

Run locally:
1. Open this folder in VS Code.
2. Install the Live Server extension.
3. Right-click index.html -> Open with Live Server.

Music:
The invitation generates a soft romantic instrumental loop in the browser. It starts after the visitor taps the opening button (browser autoplay rules require a user gesture). Use the MUSIC button to pause/resume.

RSVP:
The form uses FormSubmit and sends submissions to moalaa13469@gmail.com. The first submission may require email activation/confirmation from FormSubmit.
